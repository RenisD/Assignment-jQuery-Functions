$("button").click( function() { 
    $("#target").css("color", "red");

});

